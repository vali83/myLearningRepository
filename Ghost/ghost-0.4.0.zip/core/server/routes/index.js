var api         = require('./api'),
    admin       = require('./admin'),
    frontend    = require('./frontend');

module.exports = {
    api: api,
    admin: admin,
    frontend: frontend
};